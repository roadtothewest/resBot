# ELO301 G1 · Módulo de control secundario — proyecto Altium por etapas

Cada carpeta de `etapas/` es un **proyecto Altium completo y autónomo** (rutas relativas, sin dependencias externas): se
abre con doble clic en `ELO301_G1.PrjPcb`. Generado con Altium Designer 26 a partir del historial del repo resBot.

| Etapa | Qué contiene | Estado |
|---|---|---|
| `1_esquematico` | 4 hojas (alimentación, MCU, sensores, conectores), SchLib/PcbLib (16 símbolos, 17 huellas) y bibliotecas RCL 0603. PcbDoc todavía vacío | ERC 0 errores, 3 advertencias benignas |
| `2_pcb_ruteado` | Placa de 4 capas, 70 × 50 mm, 68 piezas, ruteo completo, Documentacion.OutJob | DRC 0 |
| `3_nodos_criticos` | SW, BST, OSC_OUT y RF_IN en Top sin vías (SW 6,0 mm; OSC_OUT 6,4; RF_IN 5,0) | DRC 0 |
| `4_costura_gnd` | + 63 vías de costura GND (188 vías) | DRC 0 |
| `5_auditoria` | Etapa 4 + auditoría del 01/11/2026: Fabricacion.OutJob (Gerber, taladro y Pick & Place verificados), antipads de 0,3 mm, cristal de 10 pF con 2 × 12 pF, L2 LQW18AN47NJ00D, identificación en serigrafía, anillo interno de J1-1, LCSC en esquemático y placa, OutJob dentro del proyecto | ERC 0 errores, DRC 0. **Partir de aquí** |

Apilado: Top 1 oz · PP7628 8,28 mil (εr 4,4) · GND · núcleo FR-4 41,9 mil · Señal-Potencia · Bottom. Total 1,59 mm.

**RF_IN:** pista de 0,35 mm ⇒ ≈ 48 Ω con máscara y el GND de Top a 0,39 mm (51 Ω como microstrip desnuda). Con 5 mm de
largo, la reflexión es despreciable (pérdida de retorno > 39 dB).

## Cómo importarlo

1. Descomprimir y copiar la carpeta de la etapa **entera** (los documentos se buscan por ruta relativa).
2. En Altium: File ▸ Open ▸ `ELO301_G1.PrjPcb`.
3. Project ▸ Compile PCB Project (ERC). Con el PcbDoc abierto, Tools ▸ Design Rule Check: debe dar 0.
4. No hay que reapuntar bibliotecas: van dentro de la carpeta.
5. Para comparar etapas, abrir dos proyectos y usar Project ▸ Show Differences entre sus PcbDoc.

## Otros contenidos

- `fabricacion/`: paquete verificado para JLCPCB (`ELO301_G1_Gerber_JLCPCB.zip`), BOM con fabricante, MPN y LCSC (verificados contra JLCPCB), CPL en mm y
  la salida directa del OutJob.
- `generadores/`: scripts que reproducen cada etapa (la 5, con `pcb/auditoria*.py`) y `herramientas/jlcpcb.py`, que arma
  y verifica el paquete de fabricación.
- `docs/` y `esquematicos/`: documento de diseño, especificaciones y capturas de las hojas.

## Pendientes conocidos

- PDF del esquemático (Altium se colgó al publicarlo).
- Revisar el zip en el «Gerber Viewer» de JLCPCB, que pide una cuenta. El cotizador ya lo reconoce bien: 4 capas,
  70 × 50 mm, 233 agujeros. Solo cuenta 4 sin metalizar cuando el taladro tiene 2.
- Si se corre «Design ▸ Update PCB Document», desmarcar «Remove Net Classes». Alimentacion y Potencia existen solo en
  la placa y sin ellas las reglas `Ancho_*` no aplican; `generadores/pcb/clases_red.py` las repone.
- No volver a correr `generadores/pcb/costura.py` sobre las etapas 4 y 5 (duplicaría las vías).
