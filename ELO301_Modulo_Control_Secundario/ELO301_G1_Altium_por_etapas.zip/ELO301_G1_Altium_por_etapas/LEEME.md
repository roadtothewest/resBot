# ELO301 G1 · Módulo de control secundario — proyecto Altium por etapas

Cada carpeta de `etapas/` es un **proyecto Altium completo y autónomo** (rutas relativas, sin dependencias externas): se abre con doble clic en `ELO301_G1.PrjPcb`. Probado con Altium Designer 26.

| Etapa | Qué contiene | Estado |
|---|---|---|
| `1_esquematico` | 4 hojas (Alimentación, MCU STM32G431, Sensores, Conectores), `ELO301_G1.SchLib`/`PcbLib` (16 símbolos, 17 huellas) y bibliotecas RCL 0603. PcbDoc aún sin diseñar | ERC 0 errores, 3 advertencias benignas |
| `2_pcb_ruteado` | Placa 4 capas 70×50 mm, 68 piezas colocadas, ruteo completo, `Documentacion.OutJob` | DRC 0 |
| `3_nodos_criticos` | SW, BST, OSC_OUT y RF_IN en Top sin vías (SW 6,0 mm; OSC_OUT 6,4; RF_IN 5,0) | DRC 0 |
| `4_final_costura_y_fabricacion` | + 63 vías de costura GND (188 vías en total) y `Fabricacion.OutJob` | DRC 0 — **partir de aquí para editar** |

Apilado (Layer Stack Manager): Top 1 oz · PP7628 8,28 mil (εr 4,4) · **GND** · núcleo FR-4 41,9 mil · **Señal-Potencia** · Bottom. Total 1,59 mm.
**RF_IN:** pista de 0,35 mm sobre 8,28 mil de prepreg y plano GND ⇒ ≈ 49 Ω (Hammerstad-Jensen; el ancho exacto para 50 Ω es 0,364 mm). Confirmar con la calculadora del fabricante.

## Cómo importarlo
1. Descomprimir y copiar la carpeta de la etapa deseada (entera) a una ruta local.
2. Altium: *File ▸ Open* ▸ `ELO301_G1.PrjPcb`. Las bibliotecas y hojas se cargan solas.
3. Revisar: *Project ▸ Compile PCB Project* (ERC), abrir `ELO301_G1.PcbDoc`, *Tools ▸ Design Rule Check* (debe dar 0).
4. Si piden un archivo, no hay que reapuntar nada: todo está en la misma carpeta.
5. Para comparar etapas: *Project ▸ Show Differences* entre dos `PcbDoc`, o abrirlas lado a lado.

## Otros contenidos
- `fabricacion/`: Gerber, taladro NC, Pick&Place, BOM y zip listo para JLCPCB (etapa 4). Sin números LCSC.
- `generadores/`: scripts que construyeron todo (hojas del esquemático, huellas/símbolos, colocación/ruteo/costura del PCB y herramientas de control de Altium). Reproducen la etapa siguiente a partir de la anterior.
- `docs/`, `esquematicos/`: diseño v5, especificaciones e imágenes de las hojas y la placa.

## Pendientes conocidos
- PDF del esquemático (el `run_output_jobs` se colgó).
- Revisar los Gerbers en el visor del fabricante y añadir códigos LCSC al BOM.
- Pines de la BMI270 (símbolo BMI160 con pines verificados) y del ATGM336H (símbolo MAX-M8Q renombrado) están adaptados: revisar antes de fabricar.
- No re-ejecutar `generadores/pcb/costura.py` sobre la etapa 4: duplicaría las vías.
